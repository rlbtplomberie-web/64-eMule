# SkinN64 Minimal V14

Cette version repart de la même révision que l'APK N64-Pad-V8 fonctionnel :
`33bf7021549d7873e976884370fbd1a8e7333bc7`.

Le correctif ne remplace ni GalleryActivity, ni l'écran d'accueil, ni les menus de M64Plus AE.
Il ajoute seulement les quatre pads SkinN64, leurs positions, leurs commandes tactiles, l'icône
SkinN64 et le placement de l'image du jeu dans le cadre noir.
